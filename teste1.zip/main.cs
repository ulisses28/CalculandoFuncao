using System;

class MainClass {
  public static void Main (string[] args) {
    Funcao resultado = new Funcao();
    Console.WriteLine ("======================================");
    Console.WriteLine("A média é {0}", Funcao.Media(2.55,5.67,6.7));
    Console.WriteLine(Funcao.Expressao1(4.60,0.75));
    Console.WriteLine(Funcao.Expressao2(4.60,0.75,3.25));
    Console.WriteLine(Funcao.Expressao3(4.60,0.75,3.25));
    //Console.WriteLine(Funcao.Soma());
    Console.WriteLine("=========================================");
    Console.WriteLine("/n fim");
    Console.ReadKey();
  }
}
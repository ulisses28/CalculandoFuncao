using System;

    class Funcao{
        private double casa;
    
    
        // calcular uma media com tres variaveis numa Função
        public static double Media(double a, double b, double c){
            return (a * b * c)/3;
        }
        public static double Expressao1(double x,double y){
            return ((2* x)+Math.Pow((4-y),2)+1);
            
        }
        public static double Expressao2(double d,double e, double f){
            return ((2 * d)*(Math.Pow(e, 8))/f);
        }
        public static double Expressao3(double m,double n, double p){
            return (2*m)+(Math.Pow((7/n),0.2))*p;
        }
        
    
}


        
